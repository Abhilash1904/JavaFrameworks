package com.example.jpaHibernate.Hibernateapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateappApplicationTests {

	@Test
	void contextLoads() {
	}

}
