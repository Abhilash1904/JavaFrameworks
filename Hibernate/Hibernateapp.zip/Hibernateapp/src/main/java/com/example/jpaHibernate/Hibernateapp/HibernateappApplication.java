package com.example.jpaHibernate.Hibernateapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateappApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernateappApplication.class, args);
	}

}
